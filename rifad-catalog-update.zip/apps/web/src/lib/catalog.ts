import type { Product, ProductIconKey } from '@/config/products';
import type { Locale } from '@/i18n/routing';

/** نسخة مبسّطة وقابلة للتمرير للمكونات الـ client، بنصوص اللغة الحالية. */
export type ProductView = {
  slug: string;
  href: string;
  icon: ProductIconKey;
  image?: string;
  name: string;
  description: string;
  features: { icon: ProductIconKey; label: string }[];
  specs: { label: string; value: string }[];
  price: number;
  compareAtPrice?: number;
  discount?: number;
  sales: number;
};

export function discountPercent(price: number, compareAtPrice?: number) {
  if (!compareAtPrice || compareAtPrice <= price) return undefined;
  return Math.round(((compareAtPrice - price) / compareAtPrice) * 100);
}

export function toProductView(product: Product, locale: Locale): ProductView {
  return {
    slug: product.slug,
    href: `/categories/${product.categorySlug}/${product.slug}`,
    icon: product.icon,
    image: product.image,
    name: product.name[locale],
    description: product.description[locale],
    features: product.features.map((feature) => ({
      icon: feature.icon,
      label: feature.label[locale],
    })),
    specs: product.specs.map((spec) => ({ label: spec.label[locale], value: spec.value[locale] })),
    price: product.price,
    compareAtPrice: product.compareAtPrice,
    discount: discountPercent(product.price, product.compareAtPrice),
    sales: product.sales,
  };
}

export function formatNumber(value: number) {
  return value.toLocaleString('en-US');
}

export type SortKey = 'bestSellers' | 'priceAsc' | 'priceDesc' | 'discount';

export const sortKeys: SortKey[] = ['bestSellers', 'priceAsc', 'priceDesc', 'discount'];

export function sortProducts(items: ProductView[], key: SortKey) {
  const sorted = [...items];
  switch (key) {
    case 'priceAsc':
      return sorted.sort((a, b) => a.price - b.price);
    case 'priceDesc':
      return sorted.sort((a, b) => b.price - a.price);
    case 'discount':
      return sorted.sort((a, b) => (b.discount ?? 0) - (a.discount ?? 0));
    default:
      return sorted.sort((a, b) => b.sales - a.sales);
  }
}
