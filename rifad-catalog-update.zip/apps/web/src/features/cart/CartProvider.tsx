'use client';

import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import type { ReactNode } from 'react';

const STORAGE_KEY = 'rifad-cart';
const MAX_QTY = 99;

type CartLines = Record<string, number>;

type CartContextValue = {
  count: number;
  add: (slug: string, qty?: number) => void;
};

const CartContext = createContext<CartContextValue>({ count: 0, add: () => {} });

function readStorage(): CartLines {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    const parsed: unknown = raw ? JSON.parse(raw) : {};
    if (!parsed || typeof parsed !== 'object') return {};
    const lines: CartLines = {};
    for (const [slug, qty] of Object.entries(parsed)) {
      if (typeof qty === 'number' && Number.isFinite(qty) && qty > 0) {
        lines[slug] = Math.min(Math.floor(qty), MAX_QTY);
      }
    }
    return lines;
  } catch {
    return {};
  }
}

/**
 * سلة مبدئية محفوظة في المتصفح. تُستبدل بسلة حقيقية (Supabase) عند بناء صفحة الدفع.
 */
export function CartProvider({ children }: { children: ReactNode }) {
  const [lines, setLines] = useState<CartLines>({});
  const [ready, setReady] = useState(false);

  useEffect(() => {
    setLines(readStorage());
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(lines));
    } catch {
      /* التخزين غير متاح: نكمل بدون حفظ */
    }
  }, [lines, ready]);

  const add = useCallback((slug: string, qty = 1) => {
    setLines((current) => ({
      ...current,
      [slug]: Math.min((current[slug] ?? 0) + Math.max(1, qty), MAX_QTY),
    }));
  }, []);

  const value = useMemo<CartContextValue>(
    () => ({ count: Object.values(lines).reduce((sum, qty) => sum + qty, 0), add }),
    [lines, add],
  );

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  return useContext(CartContext);
}
