import { PackageOpen } from 'lucide-react';
import { useTranslations } from 'next-intl';
import { buttonVariants } from '@rifad/ui';
import { TransitionLink } from '@/components/navigation/TransitionLink';

export function EmptyCategory() {
  const t = useTranslations('catalog.empty');

  return (
    <div className="mx-auto grid max-w-md justify-items-center gap-3 px-5 py-20 text-center">
      <span className="grid size-20 place-items-center rounded-full bg-cream-200 text-burgundy-700">
        <PackageOpen className="size-10" strokeWidth={1.4} aria-hidden="true" />
      </span>
      <h2 className="text-2xl font-bold text-burgundy-900 md:text-3xl">{t('title')}</h2>
      <p className="text-lg text-ink-700">{t('text')}</p>
      <TransitionLink
        href="/categories"
        direction="back"
        className={buttonVariants({ variant: 'outline', className: 'mt-4' })}
      >
        {t('browse')}
      </TransitionLink>
    </div>
  );
}
