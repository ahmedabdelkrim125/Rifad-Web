import Image from 'next/image';
import { cn } from '@rifad/ui';
import type { ProductIconKey } from '@/config/products';
import { ProductIcon } from './ProductIcon';
import styles from './ProductVisual.module.css';

type ProductVisualProps = {
  icon: ProductIconKey;
  image?: string;
  alt?: string;
  sizes?: string;
  priority?: boolean;
  className?: string;
};

/**
 * لوحة المنتج: لو فيه صورة تظهر، وإلا تظهر لوحة بورجندي بقوس ذهبي وقاعدة رخام وأيقونة المنتج.
 */
export function ProductVisual({
  icon,
  image,
  alt = '',
  sizes = '(min-width: 1024px) 40vw, 90vw',
  priority,
  className,
}: ProductVisualProps) {
  return (
    <div className={cn(styles.visual, className)}>
      {image ? (
        <Image
          src={image}
          alt={alt}
          fill
          sizes={sizes}
          priority={priority}
          className={styles.photo}
        />
      ) : (
        <div className={styles.fallback} aria-hidden="true">
          <svg
            className={styles.arc}
            viewBox="0 0 400 200"
            preserveAspectRatio="none"
            fill="none"
            focusable="false"
          >
            <path
              d="M-10 150C90 60 250 20 420 60"
              stroke="url(#productArcGold)"
              strokeWidth="9"
              strokeLinecap="round"
            />
            <defs>
              <linearGradient id="productArcGold" x1="0" y1="0" x2="1" y2="0">
                <stop offset="0" stopColor="#b8922b" stopOpacity="0" />
                <stop offset="0.5" stopColor="#e1c25a" />
                <stop offset="1" stopColor="#d4af37" />
              </linearGradient>
            </defs>
          </svg>
          <span className={styles.glow} />
          <span className={styles.icon}>
            <ProductIcon name={icon} className="size-full" strokeWidth={1} />
          </span>
          <span className={styles.cloth} />
          <span className={styles.pedestal} />
        </div>
      )}
    </div>
  );
}
