import { useTranslations } from 'next-intl';
import { cn } from '@rifad/ui';

type DiscountBadgeProps = {
  percent: number;
  className?: string;
};

export function DiscountBadge({ percent, className }: DiscountBadgeProps) {
  const t = useTranslations('catalog.product');

  return (
    <span
      className={cn(
        'inline-flex items-center rounded-full bg-gold-300/35 px-4 py-2 text-sm font-semibold whitespace-nowrap text-burgundy-800 md:text-base',
        className,
      )}
    >
      {t('discount', { percent })}
    </span>
  );
}
