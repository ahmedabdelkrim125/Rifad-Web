import { getTranslations } from 'next-intl/server';
import { Breadcrumbs } from '@/components/navigation/Breadcrumbs';
import type { Category, CategorySlug } from '@/config/categories';
import { CategoryIcon } from '@/features/shop/CategoryIcon';
import styles from './CategoryHeader.module.css';

type CategoryHeaderProps = {
  category: Category;
};

export async function CategoryHeader({ category }: CategoryHeaderProps) {
  const names = await getTranslations('categories.names');
  const taglines = await getTranslations('categories.taglines');
  const pages = await getTranslations('pages');
  const name = names(category.nameKey);
  const tagline = taglines(category.slug as CategorySlug);

  return (
    <header className={styles.header}>
      <div className={styles.inner}>
        <Breadcrumbs
          items={[{ label: pages('categories'), href: '/categories' }, { label: name }]}
          className={styles.breadcrumbs}
        />
        <h1 className={styles.title}>
          <span className={styles.icon}>
            <CategoryIcon name={category.icon} className="size-full" />
          </span>
          <span className={styles.mask}>
            <span className={styles.word}>{name}</span>
          </span>
        </h1>
        <p className={styles.tagline}>{tagline}</p>
      </div>
    </header>
  );
}
