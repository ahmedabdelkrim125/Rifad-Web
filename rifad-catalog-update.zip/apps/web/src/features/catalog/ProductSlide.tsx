'use client';

import { TransitionLink } from '@/components/navigation/TransitionLink';
import type { ProductView } from '@/lib/catalog';
import { AddToCartButton } from './AddToCartButton';
import { DiscountBadge } from './DiscountBadge';
import { PriceBlock } from './PriceBlock';
import { ProductIcon } from './ProductIcon';
import { ProductVisual } from './ProductVisual';
import styles from './ProductSlide.module.css';

type ProductSlideProps = {
  product: ProductView;
  priority?: boolean;
};

export function ProductSlide({ product, priority }: ProductSlideProps) {
  return (
    <article className={styles.card}>
      <div className={styles.layout}>
        <ProductVisual
          icon={product.icon}
          image={product.image}
          priority={priority}
          className={styles.media}
          sizes="(min-width: 1024px) 40vw, 90vw"
        />

        <div className={styles.body}>
          <div className={styles.head}>
            <h2 className={styles.title}>
              <TransitionLink href={product.href} className={styles.titleLink}>
                {product.name}
              </TransitionLink>
            </h2>
            <p className={styles.description}>{product.description}</p>
          </div>

          <ul className={styles.features}>
            {product.features.map((feature) => (
              <li key={feature.label} className={styles.feature}>
                <span className={styles.featureIcon}>
                  <ProductIcon name={feature.icon} className="size-5 md:size-6" strokeWidth={1.6} />
                </span>
                <span className={styles.featureLabel}>{feature.label}</span>
              </li>
            ))}
          </ul>

          <div className={styles.buy}>
            {product.discount ? <DiscountBadge percent={product.discount} /> : null}
            <PriceBlock price={product.price} compareAtPrice={product.compareAtPrice} />
            <AddToCartButton slug={product.slug} className={styles.cta} />
          </div>
        </div>
      </div>
    </article>
  );
}
