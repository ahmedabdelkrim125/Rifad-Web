'use client';

import { useEffect, useRef, useState } from 'react';
import { Check, ShoppingCart } from 'lucide-react';
import { useTranslations } from 'next-intl';
import { buttonVariants } from '@rifad/ui';
import { useCart } from '@/features/cart/CartProvider';

type AddToCartButtonProps = {
  slug: string;
  quantity?: number;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
};

export function AddToCartButton({
  slug,
  quantity = 1,
  size = 'md',
  className,
}: AddToCartButtonProps) {
  const t = useTranslations('catalog.product');
  const { add } = useCart();
  const [added, setAdded] = useState(false);
  const timer = useRef<number | undefined>(undefined);

  useEffect(() => () => window.clearTimeout(timer.current), []);

  function handleClick() {
    add(slug, quantity);
    setAdded(true);
    window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => setAdded(false), 1800);
  }

  return (
    <button
      type="button"
      onClick={handleClick}
      className={buttonVariants({ size, className })}
      aria-live="polite"
    >
      {added ? (
        <>
          {t('added')}
          <Check className="size-5" aria-hidden="true" />
        </>
      ) : (
        <>
          {t('addToCart')}
          <ShoppingCart className="size-5" aria-hidden="true" />
        </>
      )}
    </button>
  );
}
