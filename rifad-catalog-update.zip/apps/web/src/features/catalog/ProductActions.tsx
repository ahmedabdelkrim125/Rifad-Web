'use client';

import { useState } from 'react';
import { Minus, Plus } from 'lucide-react';
import { useTranslations } from 'next-intl';
import { AddToCartButton } from './AddToCartButton';

type ProductActionsProps = {
  slug: string;
};

const MAX_QTY = 99;

export function ProductActions({ slug }: ProductActionsProps) {
  const t = useTranslations('catalog.product');
  const [quantity, setQuantity] = useState(1);

  return (
    <div className="flex flex-wrap items-center gap-3 md:gap-4">
      <div
        role="group"
        aria-label={t('quantity')}
        className="flex h-14 items-center rounded-full border border-cream-300 bg-cream-50/80 p-1"
      >
        <button
          type="button"
          onClick={() => setQuantity((value) => Math.max(1, value - 1))}
          disabled={quantity <= 1}
          aria-label={t('decrease')}
          className="grid size-12 place-items-center rounded-full text-burgundy-700 transition-colors hover:bg-burgundy-100 disabled:opacity-40"
        >
          <Minus className="size-5" aria-hidden="true" />
        </button>
        <output
          aria-live="polite"
          className="min-w-10 text-center text-lg font-semibold text-burgundy-900"
        >
          {quantity}
        </output>
        <button
          type="button"
          onClick={() => setQuantity((value) => Math.min(MAX_QTY, value + 1))}
          disabled={quantity >= MAX_QTY}
          aria-label={t('increase')}
          className="grid size-12 place-items-center rounded-full text-burgundy-700 transition-colors hover:bg-burgundy-100 disabled:opacity-40"
        >
          <Plus className="size-5" aria-hidden="true" />
        </button>
      </div>
      <AddToCartButton slug={slug} quantity={quantity} size="lg" className="flex-1 basis-48 px-8" />
    </div>
  );
}
