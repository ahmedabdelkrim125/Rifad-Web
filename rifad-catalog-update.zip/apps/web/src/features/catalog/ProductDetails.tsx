import { RotateCcw, ShieldCheck, Truck } from 'lucide-react';
import { getTranslations } from 'next-intl/server';
import { Breadcrumbs } from '@/components/navigation/Breadcrumbs';
import { TransitionLink } from '@/components/navigation/TransitionLink';
import type { Category } from '@/config/categories';
import { CategoryIcon } from '@/features/shop/CategoryIcon';
import type { ProductView } from '@/lib/catalog';
import { DiscountBadge } from './DiscountBadge';
import { PriceBlock } from './PriceBlock';
import { ProductActions } from './ProductActions';
import { ProductCard } from './ProductCard';
import { ProductIcon } from './ProductIcon';
import { ProductVisual } from './ProductVisual';

type ProductDetailsProps = {
  category: Category;
  product: ProductView;
  related: ProductView[];
};

export async function ProductDetails({ category, product, related }: ProductDetailsProps) {
  const t = await getTranslations('catalog');
  const names = await getTranslations('categories.names');
  const pages = await getTranslations('pages');
  const trust = await getTranslations('trust');
  const categoryName = names(category.nameKey);

  const assurances = [
    { icon: Truck, title: trust('shipping.title'), detail: trust('shipping.detail') },
    { icon: ShieldCheck, title: trust('payment.title'), detail: trust('payment.detail') },
    { icon: RotateCcw, title: trust('returns.title'), detail: trust('returns.detail') },
  ];

  return (
    <div className="mx-auto max-w-[90rem] px-5 pt-4 pb-20 md:px-10 md:pb-28">
      <Breadcrumbs
        items={[
          { label: pages('categories'), href: '/categories' },
          { label: categoryName, href: `/categories/${category.slug}` },
          { label: product.name },
        ]}
      />

      <div className="mt-6 grid gap-8 lg:grid-cols-2 lg:gap-14">
        <ProductVisual
          icon={product.icon}
          image={product.image}
          alt={product.name}
          priority
          className="aspect-[5/4] rounded-[2rem] shadow-lift lg:sticky lg:top-6 lg:self-start"
          sizes="(min-width: 1024px) 45vw, 92vw"
        />

        <div className="grid content-start gap-6">
          <TransitionLink
            href={`/categories/${category.slug}`}
            direction="back"
            className="inline-flex w-fit items-center gap-2 rounded-full bg-cream-200 px-4 py-2 text-sm font-semibold text-burgundy-700 transition-colors hover:bg-burgundy-100"
          >
            <CategoryIcon name={category.icon} className="size-4" />
            {categoryName}
          </TransitionLink>

          <h1 className="text-3xl leading-tight font-bold text-burgundy-800 md:text-5xl">
            {product.name}
          </h1>

          <div className="flex flex-wrap items-center gap-x-5 gap-y-3">
            <PriceBlock price={product.price} compareAtPrice={product.compareAtPrice} size="lg" />
            {product.discount ? <DiscountBadge percent={product.discount} /> : null}
            <span className="rounded-full bg-burgundy-100/70 px-4 py-2 text-sm font-semibold text-burgundy-700">
              {t('product.inStock')}
            </span>
          </div>

          <p className="text-lg leading-8 text-ink-700">{product.description}</p>

          <section aria-labelledby="features-title" className="grid gap-3">
            <h2 id="features-title" className="text-xl font-bold text-burgundy-800">
              {t('product.features')}
            </h2>
            <ul className="grid grid-cols-2 gap-3">
              {product.features.map((feature) => (
                <li
                  key={feature.label}
                  className="flex items-center gap-3 rounded-2xl bg-cream-50 p-3 ring-1 ring-cream-300"
                >
                  <span className="grid size-11 shrink-0 place-items-center rounded-full bg-gold-300/25 text-burgundy-700">
                    <ProductIcon name={feature.icon} className="size-6" strokeWidth={1.6} />
                  </span>
                  <span className="font-medium text-burgundy-900">{feature.label}</span>
                </li>
              ))}
            </ul>
          </section>

          <ProductActions slug={product.slug} />

          <ul className="grid gap-3 border-t border-cream-300 pt-6 sm:grid-cols-3">
            {assurances.map(({ icon: Icon, title, detail }) => (
              <li key={title} className="flex items-center gap-3">
                <Icon
                  className="size-7 shrink-0 text-burgundy-700"
                  strokeWidth={1.4}
                  aria-hidden="true"
                />
                <span className="grid text-sm leading-snug">
                  <span className="font-semibold text-burgundy-900">{title}</span>
                  <span className="text-ink-500">{detail}</span>
                </span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {product.specs.length > 0 && (
        <section aria-labelledby="specs-title" className="mt-14 md:mt-20">
          <h2 id="specs-title" className="text-2xl font-bold text-burgundy-800 md:text-3xl">
            {t('product.specs')}
          </h2>
          <dl className="mt-5 overflow-hidden rounded-3xl bg-cream-50 ring-1 ring-cream-300">
            {product.specs.map((spec, index) => (
              <div
                key={spec.label}
                className={`grid grid-cols-[minmax(0,0.8fr)_minmax(0,1.2fr)] gap-4 px-5 py-4 md:px-8 ${index % 2 === 0 ? 'bg-cream-100/70' : ''}`}
              >
                <dt className="font-semibold text-burgundy-800">{spec.label}</dt>
                <dd className="text-ink-700">{spec.value}</dd>
              </div>
            ))}
          </dl>
        </section>
      )}

      {related.length > 0 && (
        <section aria-labelledby="related-title" className="mt-14 md:mt-20">
          <h2 id="related-title" className="text-2xl font-bold text-burgundy-800 md:text-3xl">
            {t('product.related')}
          </h2>
          <ul className="mt-5 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {related.map((item) => (
              <li key={item.slug}>
                <ProductCard product={item} />
              </li>
            ))}
          </ul>
        </section>
      )}
    </div>
  );
}
