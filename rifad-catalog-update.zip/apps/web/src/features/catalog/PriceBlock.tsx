import { useTranslations } from 'next-intl';
import { cn } from '@rifad/ui';
import { formatNumber } from '@/lib/catalog';

type PriceBlockProps = {
  price: number;
  compareAtPrice?: number;
  size?: 'md' | 'lg';
  className?: string;
};

export function PriceBlock({ price, compareAtPrice, size = 'md', className }: PriceBlockProps) {
  const t = useTranslations('catalog.product');
  const currency = t('currency');

  return (
    <div className={cn('grid gap-0.5', className)}>
      <p
        className={cn(
          'flex items-baseline gap-1.5 font-bold text-burgundy-900',
          size === 'lg' ? 'text-4xl md:text-5xl' : 'text-2xl md:text-3xl',
        )}
      >
        <span dir="ltr">{formatNumber(price)}</span>
        <span className={cn('font-semibold', size === 'lg' ? 'text-xl' : 'text-base')}>
          {currency}
        </span>
      </p>
      {compareAtPrice && compareAtPrice > price && (
        <p className="text-sm text-ink-500 line-through md:text-base">
          <span className="sr-only">{t('priceBefore')}: </span>
          <span dir="ltr">{formatNumber(compareAtPrice)}</span> {currency}
        </p>
      )}
    </div>
  );
}
