import { useTranslations } from 'next-intl';
import { TransitionLink } from '@/components/navigation/TransitionLink';
import type { ProductView } from '@/lib/catalog';
import { DiscountBadge } from './DiscountBadge';
import { PriceBlock } from './PriceBlock';
import { ProductVisual } from './ProductVisual';

type ProductCardProps = {
  product: ProductView;
};

/** كارت صغير للمنتجات المشابهة. */
export function ProductCard({ product }: ProductCardProps) {
  const t = useTranslations('catalog.product');

  return (
    <TransitionLink
      href={product.href}
      className="group relative grid h-full gap-4 overflow-hidden rounded-3xl border border-white/70 bg-gradient-to-br from-cream-50 to-cream-200 p-3 shadow-[0_20px_40px_-28px_rgb(112_17_39/0.55)] transition-[transform,box-shadow] duration-500 ease-out-expo hover:-translate-y-1 hover:shadow-lift focus-visible:-translate-y-1"
    >
      <ProductVisual
        icon={product.icon}
        image={product.image}
        className="aspect-[4/3] rounded-2xl"
        sizes="(min-width: 1024px) 22vw, (min-width: 640px) 45vw, 90vw"
      />
      <div className="grid gap-2 px-2 pb-2">
        <h3 className="text-lg font-bold text-burgundy-800">{product.name}</h3>
        <div className="flex flex-wrap items-center justify-between gap-2">
          <PriceBlock price={product.price} compareAtPrice={product.compareAtPrice} />
          {product.discount ? <DiscountBadge percent={product.discount} /> : null}
        </div>
        <span className="mt-1 text-sm font-semibold text-burgundy-700 underline-offset-4 group-hover:underline">
          {t('details')}
        </span>
      </div>
    </TransitionLink>
  );
}
