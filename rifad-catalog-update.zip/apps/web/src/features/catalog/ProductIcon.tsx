import {
  AudioLines,
  BatteryFull,
  Bluetooth,
  Cpu,
  Droplets,
  Headphones,
  HardDrive,
  HeartPulse,
  Laptop,
  MemoryStick,
  Mic,
  Monitor,
  Navigation,
  Speaker,
  Volume2,
  Watch,
  type LucideIcon,
} from 'lucide-react';
import type { ProductIconKey } from '@/config/products';

const icons: Record<ProductIconKey, LucideIcon> = {
  headphones: Headphones,
  laptop: Laptop,
  watch: Watch,
  speaker: Speaker,
  audio: AudioLines,
  bluetooth: Bluetooth,
  battery: BatteryFull,
  mic: Mic,
  cpu: Cpu,
  memory: MemoryStick,
  storage: HardDrive,
  screen: Monitor,
  heartRate: HeartPulse,
  gps: Navigation,
  water: Droplets,
  bass: Volume2,
};

type ProductIconProps = {
  name: ProductIconKey;
  className?: string;
  strokeWidth?: number;
};

export function ProductIcon({ name, className, strokeWidth = 1.5 }: ProductIconProps) {
  const Icon = icons[name];
  return <Icon className={className} strokeWidth={strokeWidth} aria-hidden="true" />;
}
