'use client';

import { useCallback, useEffect, useRef, useState, type KeyboardEvent } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { useLocale, useTranslations } from 'next-intl';
import { cn } from '@rifad/ui';
import { localeMeta, type Locale } from '@/i18n/routing';
import type { ProductView } from '@/lib/catalog';
import { ProductSlide } from './ProductSlide';
import styles from './ProductCarousel.module.css';

export type CarouselMode = 'single' | 'double';

type ProductCarouselProps = {
  products: ProductView[];
  mode: CarouselMode;
  label: string;
};

export function ProductCarousel({ products, mode, label }: ProductCarouselProps) {
  const t = useTranslations('catalog.carousel');
  const locale = useLocale() as Locale;
  const rtl = localeMeta[locale].dir === 'rtl';
  const trackRef = useRef<HTMLUListElement>(null);
  const frame = useRef(0);
  const [active, setActive] = useState(0);

  const visible = mode === 'double' ? 2 : 1;
  const maxIndex = Math.max(0, products.length - visible);

  /** المسافة بين الشريحة ونقطة المحاذاة (المنتصف في وضع منتج واحد، بداية السطر في وضع منتجين). */
  const offsetOf = useCallback(
    (track: HTMLElement, slide: HTMLElement) => {
      const tr = track.getBoundingClientRect();
      const r = slide.getBoundingClientRect();
      if (mode === 'single') return r.left + r.width / 2 - (tr.left + tr.width / 2);
      const style = getComputedStyle(track);
      if (rtl) return r.right - (tr.right - parseFloat(style.paddingRight));
      return r.left - (tr.left + parseFloat(style.paddingLeft));
    },
    [mode, rtl],
  );

  const measure = useCallback(() => {
    const track = trackRef.current;
    if (!track) return;
    let best = 0;
    let bestDistance = Infinity;
    Array.from(track.children).forEach((child, index) => {
      const distance = Math.abs(offsetOf(track, child as HTMLElement));
      if (distance < bestDistance) {
        bestDistance = distance;
        best = index;
      }
    });
    setActive(Math.min(best, maxIndex));
  }, [offsetOf, maxIndex]);

  const goTo = useCallback(
    (index: number) => {
      const track = trackRef.current;
      if (!track) return;
      const target = track.children[Math.min(Math.max(index, 0), maxIndex)] as
        HTMLElement | undefined;
      if (!target) return;
      const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      track.scrollBy({ left: offsetOf(track, target), behavior: reduce ? 'auto' : 'smooth' });
    },
    [offsetOf, maxIndex],
  );

  // عند تغيير الوضع أو القائمة (ترتيب/بحث) نرجع لأول منتج
  useEffect(() => {
    const track = trackRef.current;
    if (!track) return;
    track.scrollTo({ left: 0, behavior: 'auto' });
    setActive(0);
    const id = window.requestAnimationFrame(measure);
    return () => window.cancelAnimationFrame(id);
  }, [mode, products, measure]);

  useEffect(() => {
    const onResize = () => measure();
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, [measure]);

  useEffect(() => () => window.cancelAnimationFrame(frame.current), []);

  function onScroll() {
    if (frame.current) return;
    frame.current = window.requestAnimationFrame(() => {
      frame.current = 0;
      measure();
    });
  }

  const next = () => goTo(active + 1);
  const prev = () => goTo(active - 1);
  const canPrev = active > 0;
  const canNext = active < maxIndex;

  function onKeyDown(event: KeyboardEvent) {
    const target = event.target as HTMLElement;
    if (target.closest('input, select, textarea')) return;
    if (event.key === 'ArrowLeft') (rtl ? next : prev)();
    else if (event.key === 'ArrowRight') (rtl ? prev : next)();
  }

  const isVisible = (index: number) => index >= active && index < active + visible;

  return (
    <section
      className={cn(styles.root, mode === 'double' && styles.double)}
      aria-roledescription="carousel"
      aria-label={label}
      onKeyDown={onKeyDown}
    >
      <button
        type="button"
        className={cn(styles.arrow, styles.arrowLeft)}
        onClick={rtl ? next : prev}
        disabled={rtl ? !canNext : !canPrev}
        aria-label={rtl ? t('next') : t('prev')}
      >
        <ChevronLeft className="size-6" strokeWidth={2.4} aria-hidden="true" />
      </button>
      <button
        type="button"
        className={cn(styles.arrow, styles.arrowRight)}
        onClick={rtl ? prev : next}
        disabled={rtl ? !canPrev : !canNext}
        aria-label={rtl ? t('prev') : t('next')}
      >
        <ChevronRight className="size-6" strokeWidth={2.4} aria-hidden="true" />
      </button>

      <ul ref={trackRef} className={styles.track} onScroll={onScroll}>
        {products.map((product, index) => {
          const shown = isVisible(index);
          return (
            <li
              key={product.slug}
              className={styles.slide}
              data-dim={mode === 'single' && !shown ? 'true' : undefined}
              aria-roledescription="slide"
              aria-label={t('slide', { n: index + 1, total: products.length })}
              onClickCapture={(event) => {
                if (shown) return;
                event.preventDefault();
                event.stopPropagation();
                goTo(index);
              }}
              onFocusCapture={() => {
                if (!shown) goTo(index);
              }}
            >
              <ProductSlide product={product} priority={index === 0} />
            </li>
          );
        })}
      </ul>

      {maxIndex > 0 && (
        <div className={styles.dots}>
          {Array.from({ length: maxIndex + 1 }, (_, index) => (
            <button
              key={index}
              type="button"
              className={cn(styles.dot, index === active && styles.dotActive)}
              onClick={() => goTo(index)}
              aria-label={t('goTo', { n: index + 1 })}
              aria-current={index === active ? 'true' : undefined}
            />
          ))}
        </div>
      )}
    </section>
  );
}
