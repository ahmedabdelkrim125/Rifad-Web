/** موجة بورجندي أسفل قسم المنتجات، تلتحم مع الفوتر. */
export function CategoryWaves() {
  return (
    <svg
      className="pointer-events-none absolute inset-x-0 bottom-0 -z-10 h-[clamp(3rem,9vw,8rem)] w-full"
      viewBox="0 0 1440 120"
      preserveAspectRatio="none"
      aria-hidden="true"
      focusable="false"
    >
      <path
        d="M0 30C180 70 300 120 520 120H920C1140 120 1260 70 1440 30V120H0Z"
        fill="var(--color-burgundy-700)"
      />
      <path
        d="M0 30C180 70 300 120 520 120M920 120C1140 120 1260 70 1440 30"
        fill="none"
        stroke="var(--color-gold-500)"
        strokeWidth="3"
        vectorEffect="non-scaling-stroke"
      />
    </svg>
  );
}
