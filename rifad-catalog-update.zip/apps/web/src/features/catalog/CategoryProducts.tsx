'use client';

import { useMemo, useState, useSyncExternalStore } from 'react';
import { ChevronDown, Columns2, RectangleHorizontal, Search, SearchX } from 'lucide-react';
import { useTranslations } from 'next-intl';
import { buttonVariants, cn } from '@rifad/ui';
import { sortKeys, sortProducts, type ProductView, type SortKey } from '@/lib/catalog';
import { ProductCarousel, type CarouselMode } from './ProductCarousel';

type CategoryProductsProps = {
  products: ProductView[];
  categoryName: string;
};

const WIDE_QUERY = '(min-width: 1024px)';

function subscribeWide(callback: () => void) {
  const media = window.matchMedia(WIDE_QUERY);
  media.addEventListener('change', callback);
  return () => media.removeEventListener('change', callback);
}

function useIsWide() {
  return useSyncExternalStore(
    subscribeWide,
    () => window.matchMedia(WIDE_QUERY).matches,
    () => true,
  );
}

export function CategoryProducts({ products, categoryName }: CategoryProductsProps) {
  const t = useTranslations('catalog');
  const [query, setQuery] = useState('');
  const [sort, setSort] = useState<SortKey>('bestSellers');
  const [mode, setMode] = useState<CarouselMode>('single');
  const wide = useIsWide();
  // وضع المنتجين متاح للشاشات الكبيرة فقط
  const effectiveMode: CarouselMode = wide ? mode : 'single';

  const visibleProducts = useMemo(() => {
    const needle = query.trim().toLowerCase();
    const filtered = needle
      ? products.filter((product) =>
          `${product.name} ${product.description}`.toLowerCase().includes(needle),
        )
      : products;
    return sortProducts(filtered, sort);
  }, [products, query, sort]);

  return (
    <div>
      <div className="mx-auto flex max-w-[90rem] flex-wrap items-center gap-3 px-5 md:gap-4 md:px-10">
        <label className="group flex h-12 min-w-0 flex-1 basis-full items-center gap-3 rounded-full border border-cream-300 bg-cream-50/80 ps-5 pe-5 shadow-[0_8px_20px_-14px_rgb(112_17_39/0.5)] transition-shadow focus-within:border-gold-500 focus-within:shadow-lift md:basis-[22rem] md:flex-none md:grow md:max-w-xl">
          <Search
            className="size-5 shrink-0 text-burgundy-700"
            strokeWidth={1.8}
            aria-hidden="true"
          />
          <span className="sr-only">{t('toolbar.searchLabel')}</span>
          <input
            type="search"
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder={t('toolbar.searchPlaceholder', { category: categoryName })}
            className="h-full min-w-0 flex-1 bg-transparent text-base text-ink-900 outline-none placeholder:text-ink-500"
          />
        </label>

        <div className="flex flex-1 items-center justify-end gap-3 md:gap-4">
          <label className="relative flex h-12 items-center gap-2 rounded-full border border-cream-300 bg-cream-50/80 ps-5 pe-11 text-burgundy-900">
            <span className="text-ink-500">{t('toolbar.sortLabel')}:</span>
            <select
              value={sort}
              onChange={(event) => setSort(event.target.value as SortKey)}
              className="h-full cursor-pointer appearance-none bg-transparent font-medium outline-none"
            >
              {sortKeys.map((key) => (
                <option key={key} value={key}>
                  {t(`toolbar.sort.${key}`)}
                </option>
              ))}
            </select>
            <ChevronDown
              className="pointer-events-none absolute end-4 size-4 text-burgundy-700"
              strokeWidth={2.2}
              aria-hidden="true"
            />
          </label>

          <span className="hidden h-7 w-px bg-cream-300 lg:block" aria-hidden="true" />

          <div
            role="group"
            aria-label={t('toolbar.viewLabel')}
            className="hidden h-12 items-center gap-1 rounded-full border border-cream-300 bg-cream-50/80 p-1 lg:flex"
          >
            {(
              [
                ['single', RectangleHorizontal, t('toolbar.viewSingle')],
                ['double', Columns2, t('toolbar.viewDouble')],
              ] as const
            ).map(([value, Icon, label]) => (
              <button
                key={value}
                type="button"
                onClick={() => setMode(value)}
                aria-pressed={mode === value}
                aria-label={label}
                title={label}
                className={cn(
                  'grid size-10 place-items-center rounded-full transition-colors',
                  mode === value
                    ? 'bg-burgundy-700 text-cream-50'
                    : 'text-ink-500 hover:bg-burgundy-100 hover:text-burgundy-700',
                )}
              >
                <Icon className="size-5" strokeWidth={1.8} aria-hidden="true" />
              </button>
            ))}
          </div>
        </div>
      </div>

      {visibleProducts.length > 0 ? (
        <ProductCarousel
          products={visibleProducts}
          mode={effectiveMode}
          label={t('carousel.label', { category: categoryName })}
        />
      ) : (
        <div className="mx-auto grid max-w-md justify-items-center gap-3 px-5 py-20 text-center">
          <span className="grid size-16 place-items-center rounded-full bg-cream-200 text-burgundy-700">
            <SearchX className="size-8" strokeWidth={1.5} aria-hidden="true" />
          </span>
          <h2 className="text-2xl font-bold text-burgundy-900">{t('empty.noResultsTitle')}</h2>
          <p className="text-ink-700">{t('empty.noResultsText')}</p>
          <button
            type="button"
            onClick={() => setQuery('')}
            className={buttonVariants({ variant: 'outline', size: 'sm', className: 'mt-2' })}
          >
            {t('empty.clear')}
          </button>
        </div>
      )}
    </div>
  );
}
