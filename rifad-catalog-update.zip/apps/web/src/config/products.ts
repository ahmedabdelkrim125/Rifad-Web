import type { CategorySlug } from '@/config/categories';
import type { Locale } from '@/i18n/routing';

/**
 * بيانات مؤقتة للمنتجات (Mock) لحين ربط Supabase.
 * الشكل هنا هو نفس شكل الجدول المنتظر: أسماء ووصف بالعربية والإنجليزية، سعر، سعر قبل الخصم.
 */
export type Localized = Record<Locale, string>;

export const productIcons = [
  'headphones',
  'laptop',
  'watch',
  'speaker',
  'audio',
  'bluetooth',
  'battery',
  'mic',
  'cpu',
  'memory',
  'storage',
  'screen',
  'heartRate',
  'gps',
  'water',
  'bass',
] as const;

export type ProductIconKey = (typeof productIcons)[number];

export type Product = {
  slug: string;
  categorySlug: CategorySlug;
  /** أيقونة اللوحة البديلة لو مفيش صورة. */
  icon: ProductIconKey;
  /** صورة المنتج داخل public، مثال: /products/pro-wireless-headphones.webp */
  image?: string;
  name: Localized;
  description: Localized;
  features: { icon: ProductIconKey; label: Localized }[];
  specs: { label: Localized; value: Localized }[];
  price: number;
  compareAtPrice?: number;
  sales: number;
};

export const products: Product[] = [
  {
    slug: 'pro-wireless-headphones',
    categorySlug: 'electronics',
    icon: 'headphones',
    name: { ar: 'سماعة لاسلكية احترافية', en: 'Pro Wireless Headphones' },
    description: {
      ar: 'جودة صوت عالية، عزل ممتاز للضوضاء، وبطارية تدوم لفترة أطول لتجربة استماع رائعة.',
      en: 'High-quality sound, excellent noise isolation and a long-lasting battery for a great listening experience.',
    },
    features: [
      { icon: 'audio', label: { ar: 'صوت نقي', en: 'Clear sound' } },
      { icon: 'bluetooth', label: { ar: 'بلوتوث 5.3', en: 'Bluetooth 5.3' } },
      { icon: 'battery', label: { ar: 'حتى 40 ساعة', en: 'Up to 40 hours' } },
      { icon: 'mic', label: { ar: 'ميكروفون مدمج', en: 'Built-in mic' } },
    ],
    specs: [
      {
        label: { ar: 'الاتصال', en: 'Connectivity' },
        value: { ar: 'بلوتوث 5.3', en: 'Bluetooth 5.3' },
      },
      {
        label: { ar: 'مدة البطارية', en: 'Battery life' },
        value: { ar: 'حتى 40 ساعة', en: 'Up to 40 hours' },
      },
      { label: { ar: 'الميكروفون', en: 'Microphone' }, value: { ar: 'مدمج', en: 'Built-in' } },
      {
        label: { ar: 'اللون', en: 'Color' },
        value: { ar: 'بورجندي وبيج', en: 'Burgundy & beige' },
      },
    ],
    price: 1299,
    compareAtPrice: 1599,
    sales: 1820,
  },
  {
    slug: 'high-performance-laptop',
    categorySlug: 'electronics',
    icon: 'laptop',
    name: { ar: 'لابتوب بأداء فائق', en: 'High-Performance Laptop' },
    description: {
      ar: 'أداء سريع للعمل والدراسة والتصميم، مع شاشة واضحة ومساحة تخزين واسعة.',
      en: 'Fast performance for work, study and design, with a crisp display and generous storage.',
    },
    features: [
      { icon: 'cpu', label: { ar: 'معالج سريع', en: 'Fast processor' } },
      { icon: 'memory', label: { ar: 'ذاكرة 16 جيجا', en: '16 GB RAM' } },
      { icon: 'storage', label: { ar: 'تخزين 512 جيجا SSD', en: '512 GB SSD' } },
      { icon: 'screen', label: { ar: 'شاشة 15.6 بوصة', en: '15.6" display' } },
    ],
    specs: [
      { label: { ar: 'الذاكرة', en: 'Memory' }, value: { ar: '16 جيجابايت', en: '16 GB' } },
      {
        label: { ar: 'التخزين', en: 'Storage' },
        value: { ar: '512 جيجابايت SSD', en: '512 GB SSD' },
      },
      { label: { ar: 'الشاشة', en: 'Display' }, value: { ar: '15.6 بوصة', en: '15.6 inch' } },
    ],
    price: 18499,
    compareAtPrice: 20999,
    sales: 640,
  },
  {
    slug: 'sport-smart-watch',
    categorySlug: 'electronics',
    icon: 'watch',
    name: { ar: 'ساعة ذكية رياضية', en: 'Sport Smart Watch' },
    description: {
      ar: 'تابع نشاطك ونبضات قلبك ومسارك بدقة، مع بطارية تدوم أيامًا ومقاومة للماء.',
      en: 'Track your activity, heart rate and route accurately, with a multi-day battery and water resistance.',
    },
    features: [
      { icon: 'heartRate', label: { ar: 'متابعة النبض', en: 'Heart-rate tracking' } },
      { icon: 'gps', label: { ar: 'تحديد المسار GPS', en: 'GPS tracking' } },
      { icon: 'battery', label: { ar: 'بطارية لأيام', en: 'Multi-day battery' } },
      { icon: 'water', label: { ar: 'مقاومة للماء', en: 'Water resistant' } },
    ],
    specs: [
      {
        label: { ar: 'التتبع', en: 'Tracking' },
        value: { ar: 'نبض + GPS', en: 'Heart rate + GPS' },
      },
      { label: { ar: 'مقاومة الماء', en: 'Water resistance' }, value: { ar: 'نعم', en: 'Yes' } },
    ],
    price: 2199,
    compareAtPrice: 2699,
    sales: 1250,
  },
  {
    slug: 'portable-bluetooth-speaker',
    categorySlug: 'electronics',
    icon: 'speaker',
    name: { ar: 'سماعة بلوتوث محمولة', en: 'Portable Bluetooth Speaker' },
    description: {
      ar: 'صوت قوي بجهير عميق في تصميم صغير يرافقك أينما ذهبت.',
      en: 'Powerful sound with deep bass in a compact design that goes wherever you do.',
    },
    features: [
      { icon: 'bass', label: { ar: 'جهير عميق', en: 'Deep bass' } },
      { icon: 'bluetooth', label: { ar: 'بلوتوث 5.3', en: 'Bluetooth 5.3' } },
      { icon: 'water', label: { ar: 'مقاومة للرذاذ', en: 'Splash resistant' } },
      { icon: 'battery', label: { ar: 'تشغيل طويل', en: 'Long playtime' } },
    ],
    specs: [
      {
        label: { ar: 'الاتصال', en: 'Connectivity' },
        value: { ar: 'بلوتوث 5.3', en: 'Bluetooth 5.3' },
      },
      {
        label: { ar: 'الحماية', en: 'Protection' },
        value: { ar: 'مقاومة للرذاذ', en: 'Splash resistant' },
      },
    ],
    price: 899,
    compareAtPrice: 1099,
    sales: 980,
  },
];

export function getProductsByCategory(categorySlug: string) {
  return products.filter((product) => product.categorySlug === categorySlug);
}

export function getProduct(categorySlug: string, productSlug: string) {
  return products.find(
    (product) => product.categorySlug === categorySlug && product.slug === productSlug,
  );
}
