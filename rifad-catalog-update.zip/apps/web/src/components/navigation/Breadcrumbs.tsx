import { ChevronLeft, Home } from 'lucide-react';
import { getLocale, getTranslations } from 'next-intl/server';
import { cn } from '@rifad/ui';
import { siteConfig } from '@/config/site';
import { Link } from '@/i18n/navigation';
import { localePath } from '@/i18n/paths';
import { toLocale } from '@/i18n/routing';
import { serializeJsonLd } from '@/lib/json-ld';

export type Crumb = {
  label: string;
  /** بدون href = الصفحة الحالية */
  href?: string;
};

type BreadcrumbsProps = {
  items: Crumb[];
  className?: string;
};

/** مسار التنقل: الرئيسية ‹ القسم ‹ المنتج. يتبع مسار الصفحة الحالية، ويضيف بيانات BreadcrumbList للـ SEO. */
export async function Breadcrumbs({ items, className }: BreadcrumbsProps) {
  const t = await getTranslations('catalog.breadcrumb');
  const locale = toLocale(await getLocale());
  const all: Crumb[] = [{ label: t('home'), href: '/' }, ...items];

  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: all.map((crumb, index) => ({
      '@type': 'ListItem',
      position: index + 1,
      name: crumb.label,
      ...(crumb.href ? { item: `${siteConfig.url}${localePath(locale, crumb.href)}` } : {}),
    })),
  };

  return (
    <nav aria-label={t('label')} className={className}>
      <ol className="flex flex-wrap items-center gap-x-2 gap-y-1 text-sm text-ink-700 md:text-base">
        {all.map((crumb, index) => {
          const last = index === all.length - 1;
          return (
            <li key={`${crumb.label}-${index}`} className="flex items-center gap-2">
              {index === 0 && (
                <Home className="size-4 text-burgundy-700 md:size-[1.1rem]" aria-hidden="true" />
              )}
              {crumb.href && !last ? (
                <Link
                  href={crumb.href}
                  className="font-medium text-burgundy-700 transition-colors hover:text-burgundy-900"
                >
                  {crumb.label}
                </Link>
              ) : (
                <span
                  aria-current={last ? 'page' : undefined}
                  className={cn(last && 'font-semibold text-burgundy-900')}
                >
                  {crumb.label}
                </span>
              )}
              {!last && (
                <ChevronLeft
                  className="size-4 text-ink-500 ltr:rotate-180"
                  strokeWidth={2}
                  aria-hidden="true"
                />
              )}
            </li>
          );
        })}
      </ol>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: serializeJsonLd(jsonLd) }}
      />
    </nav>
  );
}
