import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { getTranslations, setRequestLocale } from 'next-intl/server';
import { PageTransition } from '@/components/motion/PageTransition';
import { getCategory } from '@/config/categories';
import { getProduct, getProductsByCategory, products } from '@/config/products';
import { siteConfig } from '@/config/site';
import { ProductDetails } from '@/features/catalog/ProductDetails';
import { localePath } from '@/i18n/paths';
import { toLocale } from '@/i18n/routing';
import { toProductView } from '@/lib/catalog';
import { serializeJsonLd } from '@/lib/json-ld';
import { buildAlternates } from '@/lib/seo';

type ProductPageProps = {
  params: Promise<{ locale: string; slug: string; product: string }>;
};

export const dynamicParams = false;

export function generateStaticParams() {
  return products.map((product) => ({ slug: product.categorySlug, product: product.slug }));
}

export async function generateMetadata({ params }: ProductPageProps): Promise<Metadata> {
  const { locale: rawLocale, slug, product: productSlug } = await params;
  const locale = toLocale(rawLocale);
  const product = getProduct(slug, productSlug);
  if (!product) return {};
  const path = `/categories/${slug}/${productSlug}`;
  return {
    title: product.name[locale],
    description: product.description[locale],
    alternates: buildAlternates(locale, path),
    openGraph: {
      type: 'website',
      title: product.name[locale],
      description: product.description[locale],
      ...(product.image ? { images: [product.image] } : {}),
    },
  };
}

export default async function ProductPage({ params }: ProductPageProps) {
  const { locale: rawLocale, slug, product: productSlug } = await params;
  const locale = toLocale(rawLocale);
  setRequestLocale(locale);

  const category = getCategory(slug);
  const product = getProduct(slug, productSlug);
  if (!category || !product) notFound();

  const view = toProductView(product, locale);
  const related = getProductsByCategory(category.slug)
    .filter((item) => item.slug !== product.slug)
    .slice(0, 3)
    .map((item) => toProductView(item, locale));

  const url = `${siteConfig.url}${localePath(locale, `/categories/${category.slug}/${product.slug}`)}`;
  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'Product',
    name: view.name,
    description: view.description,
    ...(product.image ? { image: `${siteConfig.url}${product.image}` } : {}),
    url,
    offers: {
      '@type': 'Offer',
      url,
      price: product.price,
      priceCurrency: siteConfig.currency,
      availability: 'https://schema.org/InStock',
    },
  };

  return (
    <PageTransition>
      <ProductDetails category={category} product={view} related={related} />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: serializeJsonLd(jsonLd) }}
      />
    </PageTransition>
  );
}
