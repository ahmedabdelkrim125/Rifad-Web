import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { getTranslations, setRequestLocale } from 'next-intl/server';
import { PageTransition } from '@/components/motion/PageTransition';
import { categories, getCategory, type CategorySlug } from '@/config/categories';
import { getProductsByCategory } from '@/config/products';
import { CategoryHeader } from '@/features/catalog/CategoryHeader';
import { CategoryProducts } from '@/features/catalog/CategoryProducts';
import { CategoryWaves } from '@/features/catalog/CategoryWaves';
import { EmptyCategory } from '@/features/catalog/EmptyCategory';
import { toLocale } from '@/i18n/routing';
import { toProductView } from '@/lib/catalog';
import { buildAlternates } from '@/lib/seo';

type CategoryPageProps = {
  params: Promise<{ locale: string; slug: string }>;
};

export const dynamicParams = false;

export function generateStaticParams() {
  return categories.map((category) => ({ slug: category.slug }));
}

export async function generateMetadata({ params }: CategoryPageProps): Promise<Metadata> {
  const { locale: rawLocale, slug } = await params;
  const locale = toLocale(rawLocale);
  const category = getCategory(slug);
  if (!category) return {};
  const names = await getTranslations({ locale, namespace: 'categories.names' });
  const taglines = await getTranslations({ locale, namespace: 'categories.taglines' });
  return {
    title: names(category.nameKey),
    description: taglines(category.slug as CategorySlug),
    alternates: buildAlternates(locale, `/categories/${category.slug}`),
  };
}

export default async function CategoryPage({ params }: CategoryPageProps) {
  const { locale: rawLocale, slug } = await params;
  const locale = toLocale(rawLocale);
  setRequestLocale(locale);

  const category = getCategory(slug);
  if (!category) notFound();

  const names = await getTranslations('categories.names');
  const products = getProductsByCategory(category.slug).map((product) =>
    toProductView(product, locale),
  );

  return (
    <PageTransition>
      <CategoryHeader category={category} />
      <div className="relative isolate overflow-x-clip pt-2 pb-24 md:pb-32">
        {products.length > 0 ? (
          <CategoryProducts products={products} categoryName={names(category.nameKey)} />
        ) : (
          <EmptyCategory />
        )}
        <CategoryWaves />
      </div>
    </PageTransition>
  );
}
